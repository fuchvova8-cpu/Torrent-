# InWebView TV Test

Тестовая оболочка Android TV для сайта https://inwebview.com/channels.

## Сборка
Откройте проект в Android Studio и соберите `app` / `assembleDebug`.
Либо загрузите проект в GitHub и запустите Actions → Build InWebView TV Test APK.
Готовый файл: `app/build/outputs/apk/debug/app-debug.apk`.

## Ограничения тестовой версии
- Это WebView-оболочка сайта, а не самостоятельный IPTV-плеер.
- Работа каналов зависит от совместимости сайта, его видеоплеера и DRM с WebView на конкретном ТВ.
- Если сайт требует неподдерживаемые DRM/кодеки или блокирует WebView, потребуется отдельная интеграция плеера.
